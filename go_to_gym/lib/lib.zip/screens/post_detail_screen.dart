import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_to_gym/models/post.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;

class PostDetailScreen extends StatefulWidget {
  final Post post;
  final bool isOwner;

  const PostDetailScreen({
    super.key,
    required this.post,
    required this.isOwner,
  });

  @override
  State<PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen> {
  final TextEditingController _commentController = TextEditingController();
  final currentUser = FirebaseAuth.instance.currentUser;

  String _formatTimestamp(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);
    if (diff.inDays >= 365) {
      return DateFormat('MMM dd, yyyy').format(date);
    } else {
      return timeago.format(date);
    }
  }

  Future<void> _addComment() async {
    final text = _commentController.text.trim();
    if (text.isEmpty || currentUser == null) return;

    final userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUser!.uid)
        .get();

    final username = userDoc.exists ? userDoc['username'] : currentUser!.email;

    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.post.id)
        .collection('comments')
        .add({
      'userId': currentUser!.uid,
      'username': username,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });

    _commentController.clear();
  }

  Future<void> _deleteComment(String commentId) async {
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.post.id)
        .collection('comments')
        .doc(commentId)
        .delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text('Post Details', style: TextStyle(color: Colors.black)),
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: StreamBuilder<DocumentSnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('users')
                          .doc(widget.post.userId)
                          .snapshots(),
                      builder: (context, snapshot) {
                        final data = snapshot.data?.data() as Map<String, dynamic>?;
                        final base64Image = data?['profileImageBase64'] ?? '';
                        final username = data?['username'] ?? 'User';

                        return Row(
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundImage: base64Image.isNotEmpty
                                  ? MemoryImage(base64Decode(base64Image))
                                  : const AssetImage('assets/profile_placeholder.png')
                                      as ImageProvider,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              username,
                              style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),

                  if (widget.post.imageBase64.isNotEmpty)
                    Image.memory(
                      base64Decode(widget.post.imageBase64),
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),

                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.post.description,
                          style: const TextStyle(color: Colors.black, fontSize: 16),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _formatTimestamp(widget.post.createdAt),
                          style: const TextStyle(
                              color: Color.fromARGB(202, 0, 0, 0), fontSize: 12),
                        ),
                      ],
                    ),
                  ),

                  const Divider(color: Colors.black12),

                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('posts')
                        .doc(widget.post.id)
                        .collection('comments')
                        .orderBy('createdAt', descending: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      final comments = snapshot.data!.docs;

                      return ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: comments.length,
                        itemBuilder: (context, index) {
                          final doc = comments[index];
                          final data = doc.data() as Map<String, dynamic>;
                          final createdAt = (data['createdAt'] as Timestamp?)?.toDate();
                          final isOwner = data['userId'] == currentUser?.uid;

                          return StreamBuilder<DocumentSnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('users')
                                .doc(data['userId'])
                                .snapshots(),
                            builder: (context, userSnapshot) {
                              final userData =
                                  userSnapshot.data?.data() as Map<String, dynamic>?;
                              final profileBase64 = userData?['profileImageBase64'] ?? '';
                              final username = userData?['username'] ?? 'User';

                              return ListTile(
                                leading: CircleAvatar(
                                  radius: 16,
                                  backgroundImage: profileBase64.isNotEmpty
                                      ? MemoryImage(base64Decode(profileBase64))
                                      : const AssetImage('assets/profile_placeholder.png')
                                          as ImageProvider,
                                ),
                                title: Text(
                                  username,
                                  style: const TextStyle(color: Colors.black),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      data['text'] ?? '',
                                      style: const TextStyle(color: Colors.black),
                                    ),
                                    if (createdAt != null)
                                      Text(
                                        timeago.format(createdAt),
                                        style: const TextStyle(
                                            color: Color.fromARGB(202, 0, 0, 0), fontSize: 11),
                                      ),
                                  ],
                                ),
                                trailing: isOwner
                                    ? IconButton(
                                        icon: const Icon(Icons.more_vert,
                                            color: Colors.black45),
                                        onPressed: () {},
                                      )
                                    : null,
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentController,
                    style: const TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                      hintText: 'Write a comment...',
                      hintStyle: const TextStyle(color: Colors.black),
                      filled: true,
                      fillColor: Colors.grey[200],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    onSubmitted: (_) => _addComment(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFF38BDF8)),
                  onPressed: _addComment,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}